# Hybrid voor Mac: de Markdown-editor voor mensen, AI en iedereen die publiceert

**Nieuwe macOS-app maakt de herkomst van tekst zichtbaar en brengt realtime samenwerking en publiceren met één klik naar de redactionele praktijk. 7 dagen gratis proberen**

Hybrid, een Markdown-editor voor macOS, is vanaf nu verkrijgbaar in de Mac App Store. De app helpt bij een vraag die redacties, bureaus en adviespraktijken zich in het AI-tijdperk dagelijks stellen: wie heeft dit eigenlijk geschreven? In Hybrid draagt elke passage haar herkomst: zelf getypt, gemarkeerd als AI-gegenereerd, toegeschreven aan een benoemde bron of bijgedragen door een collega. Deze toeschrijving overleeft bewaren, delen en samen bewerken — en maakt transparantie zo tot werkwijze in plaats van een correctie achteraf.

De app is ontwikkeld door journalist Pascal Hugo, die al bijna 20 jaar als redacteur en mediaprofessional werkt. *„In redacties, bureaus en adviespraktijken schrijven mensen en AI-systemen allang samen aan teksten. Maar er was tot nu toe geen app die deze samenwerking eerlijk weergeeft”*, zegt Hugo. *„De tools doen alsof een tekst uit één stuk bestaat. In werkelijkheid is het een weefsel van eigen zinnen, AI-suggesties en citaten. Hybrid toont dat weefsel.”*

## De herkomst van een passage markeren

AI-passages markeert de auteur zelf met één klik — en het label is net zo makkelijk weer te verwijderen. De markering is daarmee geen extern bewijs maar een werkinstrument: ze helpt om tijdens het schrijven en herzien overzicht te houden over welke passages waarvandaan komen. Externe bronnen zoals Wikipedia kunnen een eigen naam en een gekleurd label bij de alinea krijgen. De zijbalk toont het aandeel van elke deelnemer in het document, bijvoorbeeld 57 procent zelf geschreven, 25 procent AI-gegenereerd, 18 procent uit een externe bron. Wat wordt opgeslagen blijft puur Markdown: de herkomstgegevens reizen als één onzichtbare opmerking mee in het .md-bestand, dat elke andere editor kan openen.

De geschreven tekst kan met één klik naar een Word-document of een pdf worden geëxporteerd, bijvoorbeeld om hem met de klant af te stemmen. Voor online publiceren biedt Hybrid de mogelijkheid het artikel als html te exporteren — inclusief ingesloten afbeeldingen, tabellen en links. Het document kan daarna zonder verdere opmaak in WordPress en andere contentmanagementsystemen worden geplakt. De labels blijven in het Markdown-bestand van de auteur en duiken in geen van de geëxporteerde versies op.

> „Wie met AI schrijft, raakt snel het overzicht kwijt welke zin van wie is”, zegt Hugo. „Als een tekst verschijnt, wil ik nog weten wat van mij komt, wat uit het interview en wat uit de chatbot. Dat antwoord moet het document me zelf geven, niet mijn geheugen.”

## Waarom Markdown?

Dat Hybrid op Markdown bouwt, heeft een simpele reden: Markdown-bestanden zijn voor mensen en AI-tools even makkelijk te lezen en te bewerken. Het is daarmee het perfecte formaat voor de samenwerking tussen mens en machine. Tegelijk blijft elk Hybrid-document een gewoon .md-bestand zonder leveranciersbinding, dat elke andere editor kan openen.

## Vergelijken, samenwerken, publiceren

Soms wil je bijna gelijke documenten met elkaar vergelijken om de verschillen te vinden. Waarin verschilt de tekst van ChatGPT van die van Claude? Om bijvoorbeeld de prestaties van AI-modellen te vergelijken, heeft Hybrid een zij-aan-zij-vergelijking aan boord: verschillen worden desgewenst in kleur gemarkeerd en geteld. Met één klik kan de tekst terug naar ChatGPT, Claude, Perplexity of een tool naar keuze om verder te worden bewerkt. Wordt het resultaat in de tekst geplakt, dan kan de auteur het zelf als „AI-gegenereerd” markeren.

De realtime samenwerking met collega's of externen loopt via de iCloud van de documenteigenaar: genodigden schrijven live mee, elke passage draagt naam en kleur van de auteur. Tijdens het typen verschijnt een indicator met pulserende puntjes. Het document verlaat nooit het account van de eigenaar. Gasten hebben voor de samenwerking een eigen iCloud-account nodig, maar schrijven mee zonder eigen abonnement. Om de gegevens te beschermen kunnen gasten het bestand niet exporteren en geen eigen kopie bewaren.

Voor publicatie kopieert Hybrid het document als opgemaakte HTML met ingesloten afbeeldingen — klaar om te plakken in WordPress en andere contentmanagementsystemen. Daarbij komen export naar PDF en Word, een livevoorbeeld als eigen venster of gedeelde weergave, een automatische versiegeschiedenis, afbeeldingen en tabellen via slepen en neerzetten en een Touch ID-vergrendeling.

## Automatische versiegeschiedenis

Tijdens het schrijven bewaart Hybrid automatisch tussenstanden, ongeveer tien seconden na de laatste aanslag, zonder dat de auteur eraan hoeft te denken. Elke stand verschijnt met tijdstempel in de geschiedenis van de zijbalk, is te bekijken en met één klik te herstellen. De huidige stand wordt daarvóór zelf als versie bewaard, er gaat dus niets verloren. De geschiedenis leeft niet in het bestand maar in het iCloud-account van de auteur: het Markdown-bestand blijft slank en doorgegeven documenten bevatten geen oude versies. Gewiste passages reizen niet stiekem mee. De geschiedenis is via een stabiele kenmerkcode aan het document gekoppeld en vindt het ook na hernoemen of verplaatsen terug — zelfs op een andere Mac.

## Voor mensen die publiceren

Hybrid richt zich op iedereen bij wie teksten uit meerdere handen ontstaan: PR en communicatie, marketing en bureaus, redacties en journalistiek, consultancy, AI-professionals en online-publicatie- en contentteams. *„De behoefte is overal dezelfde”*, zegt Hugo. *„Of het nu een persbericht, een campagnetekst of een adviesrapport is: zodra AI meeschrijft, moet je kunnen bijhouden wat van wie is — zonder dat het het werk afremt. Precies daarvoor heb ik Hybrid gebouwd.”*

## Prijs en beschikbaarheid

Hybrid is verkrijgbaar in de [Mac App Store](https://apps.apple.com/app/hybrid-editor/id6809209701) en is na installatie **7 dagen gratis en volledig te gebruiken** — zonder account en zonder betaalgegevens. Daarna ontgrendelt het abonnement Hybrid Pro alle functies voor **2,99 euro per maand of 24,99 euro per jaar**. Zonder abonnement blijft Hybrid een lezer voor Markdown-documenten. De app draait op macOS 13 (Ventura) of nieuwer, op Apple Silicon en Intel, en is beschikbaar in negen talen: Duits, Engels, Frans, Spaans, Italiaans, Portugees, Nederlands, Japans en vereenvoudigd Chinees. Een versie voor iPhone en iPad is in de maak; de openbare bèta via Apples TestFlight is al begonnen. Wie vooraf wil meeschrijven en feedback wil geven, kan gratis meedoen: [testflight.apple.com/join/vSs27gRv](https://testflight.apple.com/join/vSs27gRv).

## Over de ontwikkelaar

Pascal Hugo werkt al bijna 20 jaar als journalist, redacteur en mediaprofessional. Hybrid is ontstaan uit zijn eigen redactionele praktijk: als antwoord op een kloof tussen AI-tools die schrijven, redactietools die er niets van willen weten en ontoereikende exportfuncties voor online publiceren.

## Perscontact

Pascal Hugo
E-Mail: pascal@pascalhugo.de
Web: [hybrid-editor.com](https://hybrid-editor.com)

*Overname vrij van rechten; een bewijsexemplaar wordt op prijs gesteld.*
